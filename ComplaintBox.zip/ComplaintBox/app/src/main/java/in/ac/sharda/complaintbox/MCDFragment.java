package in.ac.sharda.complaintbox;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class MCDFragment extends Fragment {

    ImageView backIc;
    CardView roads, waste, streets;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_mcd, container, false);

        roads = v.findViewById(R.id.roads_CV);
        waste = v.findViewById(R.id.waste_CV);
        streets = v.findViewById(R.id.Street_CV);

        backIc = v.findViewById(R.id.back_ic);
        backIc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new HomeFragment()).addToBackStack(null).commit();
            }
        });

        roads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new RoadsFragment()).addToBackStack(null).commit();
            }
        });

        waste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new WasteFragment()).addToBackStack(null).commit();
            }
        });

        streets.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new StreetsFragment()).addToBackStack(null).commit();
            }
        });







        return v;
    }
}