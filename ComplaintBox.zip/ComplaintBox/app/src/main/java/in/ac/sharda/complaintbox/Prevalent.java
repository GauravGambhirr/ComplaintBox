package in.ac.sharda.complaintbox;

public class Prevalent {
    public static UserHelperClass currentOnlineUser;

    public static String UserPhoneKey = "UserPhone";
    public static String AdminUsername = "AdminUsername";
    public static String AdminPassword = "AdminPassword";

}
