package in.ac.sharda.complaintbox;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class FeedbackFragment extends Fragment {


    RecyclerView feedbacksRecView;
    FeedbackAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.fragment_feedback, container, false);

        feedbacksRecView = v.findViewById(R.id.feedbacksRecView);
        LinearLayoutManager linearLayoutManager = new  LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        feedbacksRecView.setLayoutManager(linearLayoutManager);

        FirebaseRecyclerOptions<FeedbackModel> options =
                new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("UserFeedbacks"),FeedbackModel.class)
                        .build();

        adapter = new FeedbackAdapter(options);
        feedbacksRecView.setAdapter(adapter);








        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

}