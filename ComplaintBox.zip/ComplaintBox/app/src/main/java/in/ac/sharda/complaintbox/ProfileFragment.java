package in.ac.sharda.complaintbox;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import io.paperdb.Paper;

public class ProfileFragment extends Fragment {

    FirebaseAuth mAuth;
    DatabaseReference reference;
    Button SignOutBtn;
    TextView firstName, lastName, phoneNo, email;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        mAuth = FirebaseAuth.getInstance();
        SignOutBtn = view.findViewById(R.id.signOutBtn);
        firstName = view.findViewById(R.id.firstNameTxt);
        lastName = view.findViewById(R.id.lastNameTxt);
        phoneNo = view.findViewById(R.id.phoneNoTxt);
        email = view.findViewById(R.id.emailTxt);
        Paper.init(requireActivity());

        SignOutBtn.setOnClickListener(view1 -> {
            AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
            builder1.setTitle("Sign out");
            builder1.setMessage("Are you sure, you want sign out");
            builder1.setCancelable(true);

            builder1.setPositiveButton(
                    "Yes",
                    (dialog, id) -> {
                        mAuth.signOut();
                        signOutUSer();
                    });

            builder1.setNegativeButton(
                    "No",
                    (dialog, id) -> dialog.cancel());

            AlertDialog alert11 = builder1.create();
            alert11.show();

        });

        String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);
        reference = FirebaseDatabase.getInstance().getReference("users");
        reference.child(UserPhoneKey).get().addOnCompleteListener(task -> {
            if (task.isSuccessful()){
                if(Objects.requireNonNull(task.getResult()).exists()){
                    DataSnapshot dataSnapshot = task.getResult();
                    firstName.setText(String.valueOf(dataSnapshot.child("firstName").getValue()));
                    lastName.setText(String.valueOf(dataSnapshot.child("lastName").getValue()));
                    phoneNo.setText(String.valueOf(dataSnapshot.child("mobileNo").getValue()));
                    email.setText(String.valueOf(dataSnapshot.child("email").getValue()));
                }else {
                    Toast.makeText(getActivity(), "user does not exist", Toast.LENGTH_SHORT).show();
                }
            }
        });



        return view;
    }

    private void signOutUSer() {
        Intent intent = new Intent(getActivity(),SendOTPActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}