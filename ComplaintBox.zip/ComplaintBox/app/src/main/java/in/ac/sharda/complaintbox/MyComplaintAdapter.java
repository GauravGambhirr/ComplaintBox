package in.ac.sharda.complaintbox;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class MyComplaintAdapter extends FirebaseRecyclerAdapter<ComplaintModel, MyComplaintAdapter.myviewholder> {

    public MyComplaintAdapter(@NonNull FirebaseRecyclerOptions<ComplaintModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder holder, int position, @NonNull ComplaintModel model) {
        holder.department.setText(model.getDepartment());
        holder.complaintType.setText(model.getComplainttype());
        holder.complaintId.setText(model.getComplaintid());
        holder.date.setText(model.getDate());
        holder.time.setText(model.getTime());
        holder.status.setText(model.getStatus());
        holder.myComplaintCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new MyComplaintDetails(
                        model.getCity(),
                        model.getComplaintid(),
                        model.getComplainttype(),
                        model.getDate(),
                        model.getDepartment(),
                        model.getDescription(),
                        model.getLocality(),
                        model.getState(),
                        model.getStatus(),
                        model.getSubcomplainttype(),
                        model.getTime(),
                        model.getUserid()
                )).addToBackStack(null).commit();
            }
        });
    }

    @NonNull
    @Override
    public myviewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.mycomplaint, parent, false);
        return new myviewholder(view);
    }

    public class myviewholder extends RecyclerView.ViewHolder{

        TextView department, complaintType, complaintId, date, time, status;
        CardView myComplaintCV;

        public myviewholder(@NonNull View itemView) {
            super(itemView);

            department = itemView.findViewById(R.id.department);
            complaintType = itemView.findViewById(R.id.complaintType);
            complaintId = itemView.findViewById(R.id.complaintId);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            status = itemView.findViewById(R.id.status);
            myComplaintCV = itemView.findViewById(R.id.myComplaintCV);

            if (status.getText().equals("Cancelled")) status.setTextColor(Color.RED);

        }
    }

}
