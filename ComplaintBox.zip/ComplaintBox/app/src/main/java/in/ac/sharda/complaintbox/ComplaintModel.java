package in.ac.sharda.complaintbox;

public class ComplaintModel {

    String city, complaintid, complainttype, date, department, description, locality, state, status, subcomplainttype, time, userid;

    public ComplaintModel() {
    }

    public ComplaintModel(String city, String complaintid, String complainttype, String date, String department, String description, String locality, String state, String status, String subcomplainttype, String time, String userid) {
        this.city = city;
        this.complaintid = complaintid;
        this.complainttype = complainttype;
        this.date = date;
        this.department = department;
        this.description = description;
        this.locality = locality;
        this.state = state;
        this.status = status;
        this.subcomplainttype = subcomplainttype;
        this.time = time;
        this.userid = userid;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getComplaintid() {
        return complaintid;
    }

    public void setComplaintid(String complaintid) {
        this.complaintid = complaintid;
    }

    public String getComplainttype() {
        return complainttype;
    }

    public void setComplainttype(String complainttype) {
        this.complainttype = complainttype;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocality() {
        return locality;
    }

    public void setLocality(String locality) {
        this.locality = locality;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSubcomplainttype() {
        return subcomplainttype;
    }

    public void setSubcomplainttype(String subcomplainttype) {
        this.subcomplainttype = subcomplainttype;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
