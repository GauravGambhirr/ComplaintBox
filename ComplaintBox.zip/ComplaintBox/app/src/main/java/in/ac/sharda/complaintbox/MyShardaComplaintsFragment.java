package in.ac.sharda.complaintbox;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class MyShardaComplaintsFragment extends Fragment {

    RecyclerView myShardaComplaintsRecView;
    MyShardaComplaintAdapter adapter;
    ImageView back_IC;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v =  inflater.inflate(R.layout.fragment_my_sharda_complaints, container, false);

        Paper.init(requireActivity());

        back_IC = v.findViewById(R.id.back_ic);
        back_IC.setOnClickListener(view -> {
            Fragment fragment = new ShardaFragment();
            FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.fragmentContainerView, fragment).commit();
        });

        String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);
        myShardaComplaintsRecView = v.findViewById(R.id.myShardaComplaintsRecView);
        LinearLayoutManager linearLayoutManager = new  LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        myShardaComplaintsRecView.setLayoutManager(linearLayoutManager);

        FirebaseRecyclerOptions<ShardaComplaintModel> options =
                new FirebaseRecyclerOptions.Builder<ShardaComplaintModel>()
                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Sharda University").child("UserComplaints").child(UserPhoneKey),ShardaComplaintModel.class)
                        .build();

        adapter = new MyShardaComplaintAdapter(options);
        myShardaComplaintsRecView.setAdapter(adapter);


        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}