package in.ac.sharda.complaintbox;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminFeedbackAdapter extends FirebaseRecyclerAdapter<FeedbackModel, AdminFeedbackAdapter.myviewholder6> {


    public AdminFeedbackAdapter(@NonNull FirebaseRecyclerOptions<FeedbackModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder6 holder, int position, @NonNull FeedbackModel model) {
        holder.department.setText(model.getTypeOfDepartment());
        holder.feedbackId.setText(model.getFeedbackId());
        holder.date.setText(model.getDate());
        holder.time.setText(model.getTime());
        holder.title.setText(model.getTitle());
        holder.subtitle.setText(model.getSubtitle());
        holder.description.setText(model.getDescription());
        holder.deleteFormBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                AlertDialog.Builder builder2 = new AlertDialog.Builder(activity);
                builder2.setTitle("Delete Feedback");
                builder2.setMessage("Are you sure, you want to Delete the Feedback");
                builder2.setCancelable(true);
                builder2.setPositiveButton(
                        "Yes",
                        (dialog, id) -> {
                            DatabaseReference UserFeedback = FirebaseDatabase.getInstance().getReference("Feedbacks").child("UserFeedbacks").child(model.getFeedbackId());
                            UserFeedback.removeValue();

                            DatabaseReference AdminFeedback = FirebaseDatabase.getInstance().getReference("Feedbacks").child("AdminFeedbacks").child(model.getTypeOfDepartment()).child(model.getFeedbackId());
                            AdminFeedback.removeValue();

                            dialog.dismiss();
                        });
                builder2.setNegativeButton(
                        "No",
                        (dialog, id) -> dialog.cancel());
                AlertDialog alert12 = builder2.create();
                alert12.show();
            }

        });

    }

    @NonNull
    @Override
    public myviewholder6 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adminfeedback2, parent, false);
        return new AdminFeedbackAdapter.myviewholder6(view);
    }

    public class myviewholder6 extends RecyclerView.ViewHolder {

        TextView department, feedbackId, date, time, title, subtitle, description;
        Button deleteFormBtn;

        public myviewholder6(@NonNull View itemView) {
            super(itemView);

            department = itemView.findViewById(R.id.typeOfDep);
            feedbackId = itemView.findViewById(R.id.feedbackId);
            deleteFormBtn = itemView.findViewById(R.id.deleteFeedbackBtn);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            title = itemView.findViewById(R.id.title);
            subtitle= itemView.findViewById(R.id.subtitle);
            description = itemView.findViewById(R.id.description);
        }
    }


}
