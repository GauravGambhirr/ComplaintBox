package in.ac.sharda.complaintbox;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Objects;

import io.paperdb.Paper;

public class UserDetailsActivity extends AppCompatActivity {

    TextInputLayout reg_FirstName, reg_LastName, reg_email;
    Button next_Btn;

    FirebaseDatabase rootNode;
    DatabaseReference reference;
    //public String mobileNo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_details);

        reg_FirstName = findViewById(R.id.reg_firstName);
        reg_LastName = findViewById(R.id.reg_lastName);
        next_Btn = findViewById(R.id.nextBtn);
        reg_email = findViewById(R.id.reg_email);
       Paper.init(this);

        //mobileNo = String.format("+91-%s",getIntent().getStringExtra("mobile"));

        next_Btn.setOnClickListener(view -> {
            String email = Objects.requireNonNull(reg_email.getEditText()).getText().toString();
            if(Objects.requireNonNull(reg_FirstName.getEditText()).getText().toString().isEmpty() ||
                    Objects.requireNonNull(reg_LastName.getEditText()).getText().toString().isEmpty() )   {
                Toast.makeText(UserDetailsActivity.this, "Enter details", Toast.LENGTH_SHORT).show();
            } else if(!isEmailValid(email)) {
                Toast.makeText(UserDetailsActivity.this, "Enter valid Email Address", Toast.LENGTH_SHORT).show();
            } else {
                storeUserDetails();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }


        });

    }

    private boolean isEmailValid(String email) {
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void storeUserDetails() {
        rootNode = FirebaseDatabase.getInstance();
        reference = rootNode.getReference("users").child(getIntent().getStringExtra("mobile"));

        String FirstName = Objects.requireNonNull(reg_FirstName.getEditText()).getText().toString();
        String LastName = Objects.requireNonNull(reg_LastName.getEditText()).getText().toString();
        String MobileNo = getIntent().getStringExtra("mobile");
        String email = Objects.requireNonNull(reg_email.getEditText()).getText().toString();

        Paper.book().write(Prevalent.UserPhoneKey,MobileNo);
        UserHelperClass helperClass = new UserHelperClass(FirstName, LastName, MobileNo, email);
        helperClass.setMobileNo(MobileNo);
        helperClass.setEmail(email);
        helperClass.setFirstName(FirstName);
        helperClass.setLastName(LastName);
        reference.setValue(helperClass);

    }
}