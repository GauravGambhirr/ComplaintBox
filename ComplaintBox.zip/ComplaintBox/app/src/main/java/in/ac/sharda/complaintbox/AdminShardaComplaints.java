package in.ac.sharda.complaintbox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class AdminShardaComplaints extends AppCompatActivity {

    RecyclerView AdminShardaComplaintsRecView;
    AdminShardaComplaintAdapter adapter;
    FirebaseRecyclerOptions<AdminShardaComplaintModel> options;
    TextView toolbarTxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_sharda_complaints);

        toolbarTxt = findViewById(R.id.toolbarTxt);
        ImageView back_IC = findViewById(R.id.back_ic);
        back_IC.setOnClickListener(view -> {
                    Intent intent = new Intent(getApplicationContext(), AdminShardaHome.class);
                    startActivity(intent);
        });

        String typeOfComplaints = getIntent().getStringExtra("typeOfComplaints");

        AdminShardaComplaintsRecView = findViewById(R.id.adminShardaRecView);
        LinearLayoutManager linearLayoutManager = new  LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        AdminShardaComplaintsRecView.setLayoutManager(linearLayoutManager);
        switch (typeOfComplaints) {
            case "accounts":
                String toolbarTxt2 = "Accounts Complaints";
                toolbarTxt.setText(toolbarTxt2);
                options =
                        new FirebaseRecyclerOptions.Builder<AdminShardaComplaintModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Sharda University").child("AdminComplaints").child("Accounts"), AdminShardaComplaintModel.class)
                                .build();
                break;
            case "examination":
                toolbarTxt2 = "Examination Cell Complaints";
                toolbarTxt.setText(toolbarTxt2);
                options =
                        new FirebaseRecyclerOptions.Builder<AdminShardaComplaintModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Sharda University").child("AdminComplaints").child("Examination"), AdminShardaComplaintModel.class)
                                .build();
                break;
            case "disputes":
                toolbarTxt2 = "Disputes Complaints";
                toolbarTxt.setText(toolbarTxt2);
                options =
                        new FirebaseRecyclerOptions.Builder<AdminShardaComplaintModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Sharda University").child("AdminComplaints").child("Disputes"), AdminShardaComplaintModel.class)
                                .build();
                break;
            case "mismanagement":
                toolbarTxt2 = "Mismanagement Complaints";
                toolbarTxt.setText(toolbarTxt2);
                options =
                        new FirebaseRecyclerOptions.Builder<AdminShardaComplaintModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Sharda University").child("AdminComplaints").child("Mismanagement"), AdminShardaComplaintModel.class)
                                .build();
                break;
            case "misconduct":
                toolbarTxt2 = "Misconduct Complaints";
                toolbarTxt.setText(toolbarTxt2);
                options =
                        new FirebaseRecyclerOptions.Builder<AdminShardaComplaintModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Sharda University").child("AdminComplaints").child("Misconduct"), AdminShardaComplaintModel.class)
                                .build();
                break;
        }
        adapter = new AdminShardaComplaintAdapter(options);
        AdminShardaComplaintsRecView.setAdapter(adapter);
    }
    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}