package in.ac.sharda.complaintbox;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class ShardaFragment extends Fragment {
    ImageView backIc;
    CardView accounts, examination, disputes, mismanagement, misconduct, myShardaComplaints;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_sharda, container, false);

        backIc = v.findViewById(R.id.back_ic);
        accounts = v.findViewById(R.id.accounts_CV);
        examination = v.findViewById(R.id.examination_CV);
        disputes = v.findViewById(R.id.disputes_CV);
        mismanagement = v.findViewById(R.id.mismanagement_CV);
        misconduct = v.findViewById(R.id.misconduct_CV);
        myShardaComplaints = v.findViewById(R.id.my_sharda_complaints_CV);

        backIc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new HomeFragment()).addToBackStack(null).commit();
            }
        });
        accounts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new AccountsFragment()).addToBackStack(null).commit();
            }
        });
        examination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new ExaminationFragment()).addToBackStack(null).commit();
            }
        });
        disputes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new DisputesFragment()).addToBackStack(null).commit();
            }
        });
        mismanagement.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new MismanagementFragment()).addToBackStack(null).commit();
            }
        });
        misconduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new MisconductFragment()).addToBackStack(null).commit();
            }
        });
        myShardaComplaints.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new MyShardaComplaintsFragment()).addToBackStack(null).commit();
            }
        });
        return v;
    }
}