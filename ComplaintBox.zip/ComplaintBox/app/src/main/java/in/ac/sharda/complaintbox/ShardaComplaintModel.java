package in.ac.sharda.complaintbox;

public class ShardaComplaintModel {

    String complaintid, complainttype, course , date, description, rollNo, status, subcomplainttype, systemId , time, userid;

    public ShardaComplaintModel() {
    }

    public ShardaComplaintModel(String complaintid, String complainttype, String course, String date, String description, String rollNo, String status, String subcomplainttype, String systemId, String time, String userid) {
        this.complaintid = complaintid;
        this.complainttype = complainttype;
        this.course = course;
        this.date = date;
        this.description = description;
        this.rollNo = rollNo;
        this.status = status;
        this.subcomplainttype = subcomplainttype;
        this.systemId = systemId;
        this.time = time;
        this.userid = userid;
    }

    public String getComplaintid() {
        return complaintid;
    }

    public void setComplaintid(String complaintid) {
        this.complaintid = complaintid;
    }

    public String getComplainttype() {
        return complainttype;
    }

    public void setComplainttype(String complainttype) {
        this.complainttype = complainttype;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo = rollNo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getSubcomplainttype() {
        return subcomplainttype;
    }

    public void setSubcomplainttype(String subcomplainttype) {
        this.subcomplainttype = subcomplainttype;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
