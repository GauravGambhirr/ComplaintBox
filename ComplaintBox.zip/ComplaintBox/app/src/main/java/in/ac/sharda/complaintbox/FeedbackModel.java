package in.ac.sharda.complaintbox;

public class FeedbackModel {
    String date, description, feedbackId, subtitle, time, title, typeOfDepartment, url;

    public FeedbackModel() {
    }

    public FeedbackModel(String date, String description, String feedbackId, String subtitle, String time, String title, String typeOfDepartment, String url) {
        this.date = date;
        this.description = description;
        this.feedbackId = feedbackId;
        this.subtitle = subtitle;
        this.time = time;
        this.title = title;
        this.typeOfDepartment = typeOfDepartment;
        this.url = url;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(String feedbackId) {
        this.feedbackId = feedbackId;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTypeOfDepartment() {
        return typeOfDepartment;
    }

    public void setTypeOfDepartment(String typeOfDepartment) {
        this.typeOfDepartment = typeOfDepartment;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }
}
