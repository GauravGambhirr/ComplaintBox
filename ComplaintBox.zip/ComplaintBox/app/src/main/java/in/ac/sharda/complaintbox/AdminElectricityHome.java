package in.ac.sharda.complaintbox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import io.paperdb.Paper;

public class AdminElectricityHome extends AppCompatActivity {

    TextView adminUsernameTxt;
    CardView adminLogoutCV, billingCV, powerCV, theftCV, feedbackCV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_electricity_home);

        adminUsernameTxt = findViewById(R.id.adminUsernameTxt);
        adminLogoutCV = findViewById(R.id.adminLogout_CV);
        billingCV = findViewById(R.id.billing_CV);
        powerCV = findViewById(R.id.powerOutage_CV);
        theftCV = findViewById(R.id.theft_CV);
        feedbackCV = findViewById(R.id.addFeedbacks_CV);
        Paper.init(this);
        String AdminUsername = Paper.book().read(Prevalent.AdminUsername);

        adminUsernameTxt.setText("Admin Username : " + AdminUsername);

        adminLogoutCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminLogout();
            }
        });

        feedbackCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AdminFeedback.class);
                intent.putExtra("typeOfDepartment", "Electricity");
                startActivity(intent);
            }
        });

        billingCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AdminComplaints.class);
                intent.putExtra("typeOfDepartment", "Electricity");
                intent.putExtra("typeOfComplaints", "billing");
                startActivity(intent);
            }
        });
        powerCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AdminComplaints.class);
                intent.putExtra("typeOfDepartment", "Electricity");
                intent.putExtra("typeOfComplaints", "power");
                startActivity(intent);
            }
        });
        theftCV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AdminComplaints.class);
                intent.putExtra("typeOfDepartment", "Electricity");
                intent.putExtra("typeOfComplaints", "theft");
                startActivity(intent);
            }
        });
    }
    private void AdminLogout() {
        AlertDialog.Builder builder3 = new AlertDialog.Builder(AdminElectricityHome.this);
        builder3.setTitle("Admin Logout");
        builder3.setMessage("Are you sure, You want to logout from admin panel.");
        builder3.setCancelable(false);
        builder3.setPositiveButton(
                "Logout",
                (dialog, id) -> {
                    Intent intent = new Intent(getApplicationContext(), SendOTPActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(intent);
                });
        builder3.setNegativeButton("Cancel", (dialog, id) -> dialog.cancel());;
        AlertDialog alert3 = builder3.create();
        alert3.show();
    }

    @Override
    public void onBackPressed() {
        AdminLogout();
    }
}