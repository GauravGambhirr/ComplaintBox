package in.ac.sharda.complaintbox;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class FeedbackAdapter extends FirebaseRecyclerAdapter<FeedbackModel, FeedbackAdapter.myviewholder5> {

    public FeedbackAdapter(@NonNull FirebaseRecyclerOptions<FeedbackModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder5 holder, int position, @NonNull FeedbackModel model) {
        holder.department.setText(model.getTypeOfDepartment());
        holder.feedbackId.setText(model.getFeedbackId());
        holder.date.setText(model.getDate());
        holder.time.setText(model.getTime());
        holder.title.setText(model.getTitle());
        holder.subtitle.setText(model.getSubtitle());
        holder.description.setText(model.getDescription());
        holder.fillFormBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                Uri uri = Uri.parse(model.getUrl());
                activity.startActivity(new Intent(Intent.ACTION_VIEW, uri));
            }
        });

    }

    @NonNull
    @Override
    public myviewholder5 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adminfeedback, parent, false);
        return new FeedbackAdapter.myviewholder5(view);
    }

    public class myviewholder5 extends RecyclerView.ViewHolder {

        TextView department, feedbackId, date, time, title, subtitle, description;
        Button fillFormBtn;

        public myviewholder5(@NonNull View itemView) {
            super(itemView);

            department = itemView.findViewById(R.id.typeOfDep);
            feedbackId = itemView.findViewById(R.id.feedbackId);
            fillFormBtn = itemView.findViewById(R.id.FillFeedbackBtn);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            title = itemView.findViewById(R.id.title);
            subtitle= itemView.findViewById(R.id.subtitle);
            description = itemView.findViewById(R.id.description);
        }
    }


}
