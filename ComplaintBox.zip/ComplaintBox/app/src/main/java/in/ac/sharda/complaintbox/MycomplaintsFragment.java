package in.ac.sharda.complaintbox;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class MycomplaintsFragment extends Fragment {

    RecyclerView myComplaintsRecView;
    MyComplaintAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_mycomplaints, container, false);

        Paper.init(requireActivity());
        String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);

        myComplaintsRecView = v.findViewById(R.id.myComplaintsRecView);
        LinearLayoutManager linearLayoutManager = new  LinearLayoutManager(getContext());
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        myComplaintsRecView.setLayoutManager(linearLayoutManager);

        FirebaseRecyclerOptions<ComplaintModel> options = 
                new FirebaseRecyclerOptions.Builder<ComplaintModel>()
                .setQuery(FirebaseDatabase.getInstance().getReference().child("UserComplaints").child(UserPhoneKey),ComplaintModel.class)
                .build();

        adapter = new MyComplaintAdapter(options);
        myComplaintsRecView.setAdapter(adapter);

        return v;
    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}