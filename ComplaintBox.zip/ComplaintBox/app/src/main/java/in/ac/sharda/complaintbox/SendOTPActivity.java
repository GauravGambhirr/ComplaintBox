package in.ac.sharda.complaintbox;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseException;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

import io.paperdb.Paper;

public class SendOTPActivity extends AppCompatActivity {

    EditText adminUsernameEt, adminPasswordEt;
    Button adminLoginBtn;
    TextView adminTxt, notAdminTxt;
    LinearLayout userLayout, adminLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_otpactivity);


        FirebaseAuth mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null) {
            // User is signed in (getCurrentUser() will be null if not signed in)
            Intent intent = new Intent(SendOTPActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
            // or do some other stuff that you want to do
        }


        final EditText inputMobile = findViewById(R.id.inputMobile);
        Button buttonGetOTP = findViewById(R.id.buttonGetOTP);
        final ProgressBar progressBar = findViewById(R.id.progressBar);

        adminTxt = findViewById(R.id.adminTxt);
        notAdminTxt = findViewById(R.id.notAdminTxt);
        userLayout = findViewById(R.id.layoutOfOTPVerification);
        adminLayout = findViewById(R.id.layoutOfAdminLogin);
        adminUsernameEt = findViewById(R.id.adminUsername);
        adminPasswordEt = findViewById(R.id.adminPassword);
        adminLoginBtn = findViewById(R.id.adminLoginBtn);

        buttonGetOTP.setOnClickListener(view -> {
            if (inputMobile.getText().toString().trim().isEmpty()){
                Toast.makeText(SendOTPActivity.this, "Enter Mobile", Toast.LENGTH_SHORT).show();
                return;
            }

            progressBar.setVisibility(View.VISIBLE);
            buttonGetOTP.setVisibility(View.INVISIBLE);

            PhoneAuthOptions options =
                    PhoneAuthOptions.newBuilder(mAuth)
                            .setPhoneNumber("+91" + inputMobile.getText().toString())       // Phone number to verify
                            .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                            .setActivity(this)                 // Activity (for callback binding)
                            .setCallbacks(new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

                                @Override
                                public void onCodeSent(@NonNull String verificationId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                    progressBar.setVisibility(View.GONE);
                                    buttonGetOTP.setVisibility(View.VISIBLE);
                                    Intent intent = new Intent(getApplicationContext(), VerifyOTPActivity.class);
                                    intent.putExtra("mobile", inputMobile.getText().toString());
                                    intent.putExtra("verificationId", verificationId);
                                    startActivity(intent);

                                }

                                @Override
                                public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {
                                    progressBar.setVisibility(View.GONE);
                                    buttonGetOTP.setVisibility(View.VISIBLE);
                                }

                                @Override
                                public void onVerificationFailed(@NonNull FirebaseException e) {
                                    progressBar.setVisibility(View.GONE);
                                    buttonGetOTP.setVisibility(View.VISIBLE);
                                    Toast.makeText(SendOTPActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                }
                            })          // OnVerificationStateChangedCallbacks
                            .build();
            PhoneAuthProvider.verifyPhoneNumber(options);

        });

        adminTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                     userLayout.setVisibility(View.GONE);
                     adminLayout.setVisibility(View.VISIBLE);
                     adminTxt.setVisibility(View.GONE);
                     notAdminTxt.setVisibility(View.VISIBLE);
            }
        });
        notAdminTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                userLayout.setVisibility(View.VISIBLE);
                adminLayout.setVisibility(View.GONE);
                adminTxt.setVisibility(View.VISIBLE);
                notAdminTxt.setVisibility(View.GONE);
            }
        });
        adminLoginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String adminUsername = adminUsernameEt.getText().toString().trim();
                String adminPassword = adminPasswordEt.getText().toString().trim();
                if(!(adminPassword.isEmpty() && adminUsername.isEmpty())){
                    loginToAdminPanel(adminUsername, adminPassword);
                } else {
                    Toast.makeText(SendOTPActivity.this, "Please Enter credentials",Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void loginToAdminPanel(String adminUsername, String adminPassword) {
        Paper.init(this);
        if (adminUsername.equals("admintransport001") && adminPassword.equals("transport1234")){
            Paper.book().write(Prevalent.AdminUsername,"admintransport001");
            Paper.book().write(Prevalent.AdminPassword,"transport1234");
            Intent intent = new Intent(getApplicationContext(), AdminTransportHome.class);
//            intent.putExtra("adminUsername", adminUsername);
//            intent.putExtra("adminPassword", adminPassword);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (adminUsername.equals("admineducation001") && adminPassword.equals("education1234")){
            Paper.book().write(Prevalent.AdminUsername,"admineducation001");
            Paper.book().write(Prevalent.AdminPassword,"education1234");
            Intent intent = new Intent(getApplicationContext(), AdminEducationHome.class);
//            intent.putExtra("adminUsername", adminUsername);
//            intent.putExtra("adminPassword", adminPassword);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (adminUsername.equals("adminelectricity001") && adminPassword.equals("electricity1234")){
            Paper.book().write(Prevalent.AdminUsername,"adminelectricity001");
            Paper.book().write(Prevalent.AdminUsername,"electricity1234");
            Intent intent = new Intent(getApplicationContext(), AdminElectricityHome.class);
//            intent.putExtra("adminUsername", adminUsername);
//            intent.putExtra("adminPassword", adminPassword);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (adminUsername.equals("adminmedical001") && adminPassword.equals("medical1234")){
            Paper.book().write(Prevalent.AdminUsername,"adminmedical001");
            Paper.book().write(Prevalent.AdminUsername,"medical1234");
            Intent intent = new Intent(getApplicationContext(), AdminMedicalHome.class);
//            intent.putExtra("adminUsername", adminUsername);
//            intent.putExtra("adminPassword", adminPassword);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (adminUsername.equals("adminsecurity001") && adminPassword.equals("security1234")){
            Paper.book().write(Prevalent.AdminUsername,"adminsecurity001");
            Paper.book().write(Prevalent.AdminUsername,"security1234");
            Intent intent = new Intent(getApplicationContext(), AdminSecurityHome.class);
//            intent.putExtra("adminUsername", adminUsername);
//            intent.putExtra("adminPassword", adminPassword);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (adminUsername.equals("adminmcd001") && adminPassword.equals("mcd1234")){
            Paper.book().write(Prevalent.AdminUsername,"adminmcd001");
            Paper.book().write(Prevalent.AdminUsername,"mcd1234");
            Intent intent = new Intent(getApplicationContext(), AdminMcdHome.class);
//            intent.putExtra("adminUsername", adminUsername);
//            intent.putExtra("adminPassword", adminPassword);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else if (adminUsername.equals("adminsharda001") && adminPassword.equals("sharda1234")){
            Paper.book().write(Prevalent.AdminUsername,"adminsharda001");
            Paper.book().write(Prevalent.AdminUsername,"sharda1234");
            Intent intent = new Intent(getApplicationContext(), AdminShardaHome.class);
//            intent.putExtra("adminUsername", adminUsername);
//            intent.putExtra("adminPassword", adminPassword);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);

        } else Toast.makeText(SendOTPActivity.this, "Please enter correct credentials",Toast.LENGTH_SHORT).show();
    }
}