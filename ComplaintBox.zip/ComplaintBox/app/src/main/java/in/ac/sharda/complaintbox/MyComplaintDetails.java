package in.ac.sharda.complaintbox;

import static in.ac.sharda.complaintbox.Prevalent.UserPhoneKey;

import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class MyComplaintDetails extends Fragment {

    Button deleteBtn;
    ImageView backIc;
    String city, complaintid, complainttype, date, department, description, locality, state, status, subcomplainttype, time, userid;
    TextView cityTxt, complaintidTxt, complainttypeTxt, dateTxt, departmentTxt, descriptionTxt, localityTxt, stateTxt, statusTxt, subcomplainttypeTxt, timeTxt;

    public MyComplaintDetails(String city, String complaintid, String complainttype, String date, String department, String description, String locality, String state, String status, String subcomplainttype, String time, String userid){
        this.city = city;
        this.complaintid = complaintid;
        this.complainttype = complainttype;
        this.date = date;
        this.department = department;
        this.description = description;
        this.locality = locality;
        this.state = state;
        this.status = status;
        this.subcomplainttype = subcomplainttype;
        this.time = time;
        this.userid = userid;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_my_complaint_details, container, false);

        cityTxt = v.findViewById(R.id.city);
        complaintidTxt = v.findViewById(R.id.complaintId2);
        dateTxt = v.findViewById(R.id.date);
        departmentTxt = v.findViewById(R.id.department2);
        descriptionTxt = v.findViewById(R.id.description);
        localityTxt = v.findViewById(R.id.locality);
        stateTxt = v.findViewById(R.id.state);
        statusTxt = v.findViewById(R.id.status);
        subcomplainttypeTxt = v.findViewById(R.id.subComplaintType);
        timeTxt = v.findViewById(R.id.time);
        complainttypeTxt = v.findViewById(R.id.complaintType2);
        deleteBtn = v.findViewById(R.id.deleteComplaintBtn);
        Paper.init(requireActivity());


        backIc = v.findViewById(R.id.back_ic);
        backIc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new MycomplaintsFragment()).addToBackStack(null).commit();
            }
        });

        cityTxt.setText(city);
        complaintidTxt.setText(complaintid);
        complainttypeTxt.setText(complainttype);
        dateTxt.setText(date);
        stateTxt.setText(state);
        statusTxt.setText(status);
        if (status.equals("Cancelled")) statusTxt.setTextColor(Color.RED);
        descriptionTxt.setText(description);
        departmentTxt.setText(department);
        subcomplainttypeTxt.setText(subcomplainttype);
        timeTxt.setText(time);
        localityTxt.setText(locality);

        deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder builder2 = new AlertDialog.Builder(getActivity());
                builder2.setTitle("Cancel Complaint");
                builder2.setMessage("Are you sure, you want to Cancel the Complaint");
                builder2.setCancelable(true);
                builder2.setPositiveButton(
                        "Yes",
                        (dialog, id) -> {
                            deleteComplaint();
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                            builder1.setTitle("Complaint Cancelled");
                            builder1.setMessage("Your complaint is cancelled.");
                            builder1.setCancelable(false);
                            builder1.setPositiveButton(
                                    "Go to home",
                                    (dialog1, id1) -> {
                                        Fragment fragment = new MycomplaintsFragment();
                                        FragmentTransaction fragmentTransaction = requireActivity().getSupportFragmentManager().beginTransaction();
                                        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).commit();
                                        FragmentManager fm = requireActivity().getSupportFragmentManager();
                                        for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                            fm.popBackStack();
                                        }
                                    });
                            AlertDialog alert11 = builder1.create();
                            alert11.show();
                        });
                builder2.setNegativeButton(
                        "No",
                        (dialog, id) -> dialog.cancel());
                AlertDialog alert12 = builder2.create();
                alert12.show();
            }
        });
        return v;
    }

    private void deleteComplaint() {
        String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);
        if (!status.equals("Cancelled")) {
            DatabaseReference UserComplaint = FirebaseDatabase.getInstance().getReference("UserComplaints").child(UserPhoneKey).child(complaintid);
            UserComplaint.child("status").setValue("Cancelled");

            DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Complaints").child(department).child(complainttype).child(complaintid);
            AdminComplaint.child("status").setValue("Cancelled");
            statusTxt.setTextColor(Color.RED);

        }


//            if (department.equals("Transport Department")){
//                switch (complainttype) {
//                    case "Bus Time Schedule": {
//                        DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Complaints").child("Transport Department").child("Bus Time Schedule").child(complaintid);
//                        AdminComplaint.child("status").setValue("Cancelled");
//                        statusTxt.setTextColor(Color.RED);
//                        break;
//                    }
//                    case "Fare Hike": {
//                        DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Complaints").child("Transport Department").child("Fare Hike").child(complaintid);
//                        AdminComplaint.child("status").setValue("Cancelled");
//                        statusTxt.setTextColor(Color.RED);
//                        break;
//                    }
//                    case "Traffic Issue": {
//                        DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Complaints").child("Transport Department").child("Traffic Issue").child(complaintid);
//                        AdminComplaint.child("status").setValue("Cancelled");
//                        statusTxt.setTextColor(Color.RED);
//                        break;
//                    }
//                }
//            }
//        }else {
//            Toast.makeText(getActivity(),"This complaint is already cancelled.",Toast.LENGTH_SHORT).show();
//        }

    }

    public void onBackPressed(){
        AppCompatActivity activity = (AppCompatActivity)getContext();
        activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new MycomplaintsFragment()).addToBackStack(null).commit();
    }


}