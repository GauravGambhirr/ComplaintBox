package in.ac.sharda.complaintbox;

import static in.ac.sharda.complaintbox.Prevalent.UserPhoneKey;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;

public class AdminFeedback extends AppCompatActivity {

    FirebaseDatabase rootNode;
    DatabaseReference referenceOfFeedbackToAdmin, referenceOfFeedbackToUser;

    RecyclerView adminFeedbacksRecView;
    AdminFeedbackAdapter adapter;
    FirebaseRecyclerOptions<FeedbackModel> options;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_feedback);
        
        String typeOfDepartment = getIntent().getStringExtra("typeOfDepartment");

        FloatingActionButton addFeedbackBtn = findViewById(R.id.addFeedbackBtn);
        ImageView back_IC = findViewById(R.id.back_ic);
        back_IC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });


        addFeedbackBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog dialog = new Dialog(AdminFeedback.this);
                dialog.setContentView(R.layout.addfeedbackdialog);

                Button cancelBtn = dialog.findViewById(R.id.cancel_btn);
                Button submitBtn = dialog.findViewById(R.id.submit_btn);
                TextView typeOfDep = dialog.findViewById(R.id.typeOfDep);
                EditText title_et = dialog.findViewById(R.id.titleOfFeedback_et);
                EditText subtitle_et = dialog.findViewById(R.id.subtitleOfFeedback_et);
                EditText description_et = dialog.findViewById(R.id.addFeedbackDesc_et);
                EditText url_et = dialog.findViewById(R.id.addFeedbackUrl_et);

                String typeOFDep2 = "";

                switch (typeOfDepartment) {
                    case "Transport":
                        typeOFDep2 = "Transport Department";
                        break;
                    case "Education":
                        typeOFDep2 = "Education Department";
                        break;
                    case "Electricity":
                        typeOFDep2 = "Electricity Department";
                        break;
                    case "Medical":
                        typeOFDep2 = "Medical Care Department";
                        break;
                    case "Mcd":
                        typeOFDep2 = "Municipal Corporation Department";
                        break;
                    case "Security":
                        typeOFDep2 = "Security Department";
                        break;
                    case "Sharda":
                        typeOFDep2 = "Sharda University";
                        break;
                }

                typeOfDep.setText(typeOFDep2);

                cancelBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                String finalTypeOFDep = typeOFDep2;
                submitBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        String title = title_et.getText().toString().trim();
                        String subtitle = subtitle_et.getText().toString().trim();
                        String desc = description_et.getText().toString().trim();
                        String url = url_et.getText().toString().trim();
                        if (title.isEmpty() || subtitle.isEmpty() || desc.isEmpty() || url.isEmpty()) {
                            Toast.makeText(AdminFeedback.this, "Enter details", Toast.LENGTH_SHORT).show();
                        } else {
                            submitFeedback();
                            dialog.dismiss();
                        }
                    }

                    private void submitFeedback() {
                        final String saveCurrentTime, saveCurrentDate, feedbackId2, feedbackId1;
                        Calendar calForDate = Calendar.getInstance();
                        SimpleDateFormat currentDate = new SimpleDateFormat("MM,dd,yyyy");
                        saveCurrentDate = currentDate.format(calForDate.getTime());
                        SimpleDateFormat currentTime = new SimpleDateFormat("HH,mm,ss a");
                        saveCurrentTime = currentTime.format(calForDate.getTime());

                        SimpleDateFormat currentDate1 = new SimpleDateFormat("MMddyyyy");
                        feedbackId1 = currentDate1.format(calForDate.getTime());
                        SimpleDateFormat currentTime2 = new SimpleDateFormat("HHmmss");
                        feedbackId2 = currentTime2.format(calForDate.getTime());

                        String feedbackID = feedbackId1 + feedbackId2;

                        rootNode = FirebaseDatabase.getInstance();
                        referenceOfFeedbackToAdmin = rootNode.getReference("Feedbacks").child("AdminFeedbacks").child(finalTypeOFDep).child(feedbackID);
                        referenceOfFeedbackToUser = rootNode.getReference("Feedbacks").child("UserFeedbacks").child(feedbackID);

                        final HashMap<String, Object> FeedbackMap = new HashMap<>();
                        FeedbackMap.put("feedbackId", feedbackID);
                        FeedbackMap.put("date", saveCurrentDate);
                        FeedbackMap.put("time", saveCurrentTime);
                        FeedbackMap.put("title", title_et.getText().toString().trim());
                        FeedbackMap.put("subtitle", subtitle_et.getText().toString().trim());
                        FeedbackMap.put("description", description_et.getText().toString().trim());
                        FeedbackMap.put("url", url_et.getText().toString().trim());
                        FeedbackMap.put("typeOfDepartment", finalTypeOFDep);

                        referenceOfFeedbackToUser.updateChildren(FeedbackMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (!task.isSuccessful())
                                    Toast.makeText(AdminFeedback.this, "Error occurred in updating userView of feedbacks", Toast.LENGTH_SHORT).show();
                            }
                        });
                        referenceOfFeedbackToAdmin.updateChildren(FeedbackMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (!task.isSuccessful())
                                    Toast.makeText(AdminFeedback.this, "Error occurred in updating adminView of feedbacks", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }


                });

                dialog.setCanceledOnTouchOutside(false);
                dialog.getWindow().setBackgroundDrawableResource(R.drawable.dialog);
                dialog.show();
            }


        });

        adminFeedbacksRecView = findViewById(R.id.adminFeedbacksRecView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        adminFeedbacksRecView.setLayoutManager(linearLayoutManager);

        switch (typeOfDepartment) {
            case "Transport":
                options =
                        new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("AdminFeedbacks").child("Transport Department"), FeedbackModel.class)
                                .build();

                break;
            case "Education":
                options =
                        new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("AdminFeedbacks").child("Education Department"), FeedbackModel.class)
                                .build();
                break;
            case "Electricity":
                options =
                        new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("AdminFeedbacks").child("Electricity Department"), FeedbackModel.class)
                                .build();
                break;
            case "Medical":
                options =
                        new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("AdminFeedbacks").child("Medical Care Department"), FeedbackModel.class)
                                .build();
                break;
            case "Mcd":
                options =
                        new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("AdminFeedbacks").child("Municipal Corporation Department"), FeedbackModel.class)
                                .build();
                break;
            case "Security":
                options =
                        new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("AdminFeedbacks").child("Security Department"), FeedbackModel.class)
                                .build();
                break;
            case "Sharda":
                options =
                        new FirebaseRecyclerOptions.Builder<FeedbackModel>()
                                .setQuery(FirebaseDatabase.getInstance().getReference().child("Feedbacks").child("AdminFeedbacks").child("Sharda University"), FeedbackModel.class)
                                .build();
                break;
        }

        adapter = new AdminFeedbackAdapter(options);
        adminFeedbacksRecView.setAdapter(adapter);


        
    }
    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }
}
