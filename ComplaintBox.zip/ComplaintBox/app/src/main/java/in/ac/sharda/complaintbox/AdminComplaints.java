package in.ac.sharda.complaintbox;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class AdminComplaints extends AppCompatActivity {

    RecyclerView AdminTrafficIssueComplaintsRecView;
    AdminComplaintAdapter adapter;
    FirebaseRecyclerOptions<AdminComplaintModel> options;
    TextView toolbarTxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_complaints);

        toolbarTxt = findViewById(R.id.toolbarTxt);
        ImageView back_IC = findViewById(R.id.back_ic);


        String typeOfComplaints = getIntent().getStringExtra("typeOfComplaints");
        String typeOfDepartment = getIntent().getStringExtra("typeOfDepartment");


        AdminTrafficIssueComplaintsRecView = findViewById(R.id.adminTrafficIssueRecView);
        LinearLayoutManager linearLayoutManager = new  LinearLayoutManager(this);
        linearLayoutManager.setReverseLayout(true);
        linearLayoutManager.setStackFromEnd(true);
        AdminTrafficIssueComplaintsRecView.setLayoutManager(linearLayoutManager);



        switch (typeOfDepartment) {
            case "Transport" :
                back_IC.setOnClickListener(view -> {
                    Intent intent = new Intent(getApplicationContext(), AdminTransportHome.class);
                    startActivity(intent);
                });
                switch (typeOfComplaints) {
                    case "trafficIssue":
                        String toolbarTxt2 = "Traffic Issue Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Transport Department").child("Traffic Issue"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "busTime":
                        toolbarTxt2 = "Bus Time Schedule Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Transport Department").child("Bus Time Schedule"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "fareHike":
                        toolbarTxt2 = "Fare Hike Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Transport Department").child("Fare Hike"), AdminComplaintModel.class)
                                        .build();

                        break;
                }
                break;
            case "Security" :
                back_IC.setOnClickListener(view -> {
                    Intent intent = new Intent(getApplicationContext(), AdminSecurityHome.class);
                    startActivity(intent);
                });
                switch (typeOfComplaints) {
                    case "police":
                        String toolbarTxt2 = "Police Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Security Department").child("Police"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "safety":
                        toolbarTxt2 = "Safety Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Security Department").child("Safety"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "fireStation":
                        toolbarTxt2 = "Fire Station Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Security Department").child("Fire"), AdminComplaintModel.class)
                                        .build();

                        break;
                }
                break;
            case "Education" :
                back_IC.setOnClickListener(view -> {
                    Intent intent = new Intent(getApplicationContext(), AdminEducationHome.class);
                    startActivity(intent);
                });
                switch (typeOfComplaints) {
                    case "school":
                        String toolbarTxt2 = "Schools Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Education Department").child("Schools"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "subsidiary":
                        toolbarTxt2 = "Subsidiary Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Education Department").child("Education Subsidiary"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "scholarship":
                        toolbarTxt2 = "Scholarship Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Education Department").child("Scholarship"), AdminComplaintModel.class)
                                        .build();
                        break;
                }
                break;
            case "Electricity" :
                back_IC.setOnClickListener(view -> {
                    Intent intent = new Intent(getApplicationContext(), AdminElectricityHome.class);
                    startActivity(intent);
                });
                switch (typeOfComplaints) {
                    case "billing":
                        String toolbarTxt2 = "Billing Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Electricity Department").child("Billing"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "power":
                        toolbarTxt2 = "Power Outage Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Electricity Department").child("Power Outage"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "theft":
                        toolbarTxt2 = "Theft/Unauthorized Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Electricity Department").child("Theft or Unauthorized use of Electricity"), AdminComplaintModel.class)
                                        .build();

                        break;
                }
                break;
            case "Mcd" :
                back_IC.setOnClickListener(view -> {
                    Intent intent = new Intent(getApplicationContext(), AdminMcdHome.class);
                    startActivity(intent);
                });
                switch (typeOfComplaints) {
                    case "roads":
                        String toolbarTxt2 = "Roads Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Municipal Corporation Department").child("Roads"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "waste":
                        toolbarTxt2 = "Waste Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Municipal Corporation Department").child("Waste"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "streets":
                        toolbarTxt2 = "Streets Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Municipal Corporation Department").child("Streets"), AdminComplaintModel.class)
                                        .build();

                        break;
                }
                break;
            case "Medical" :
                back_IC.setOnClickListener(view -> {
                    Intent intent = new Intent(getApplicationContext(), AdminMedicalHome.class);
                    startActivity(intent);
                });
                switch (typeOfComplaints) {
                    case "health":
                        String toolbarTxt2 = "Health Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Medical Care Department").child("Health"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "staff":
                        toolbarTxt2 = "Medical Staff Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Medical Care Department").child("Medical Staff"), AdminComplaintModel.class)
                                        .build();

                        break;
                    case "services":
                        toolbarTxt2 = "Medical Services Complaints";
                        toolbarTxt.setText(toolbarTxt2);
                        options =
                                new FirebaseRecyclerOptions.Builder<AdminComplaintModel>()
                                        .setQuery(FirebaseDatabase.getInstance().getReference().child("Complaints").child("Medical Care Department").child("Medical Services"), AdminComplaintModel.class)
                                        .build();

                        break;
                }
                break;
        }

        adapter = new AdminComplaintAdapter(options);
        AdminTrafficIssueComplaintsRecView.setAdapter(adapter);

    }

    @Override
    public void onStart() {
        super.onStart();
        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

}