package in.ac.sharda.complaintbox;

import android.app.Dialog;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

public class AdminShardaComplaintAdapter extends FirebaseRecyclerAdapter<AdminShardaComplaintModel, AdminShardaComplaintAdapter.myviewholder4> {

    public String complaintType2,statusType;

    public AdminShardaComplaintAdapter(@NonNull FirebaseRecyclerOptions<AdminShardaComplaintModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder4 holder, int position, @NonNull AdminShardaComplaintModel model) {
        holder.complaintId.setText(model.getComplaintid());
        holder.date.setText(model.getDate());
        holder.time.setText(model.getTime());
        holder.status.setText(model.getStatus());
        holder.userId.setText(model.getUserid());
        holder.subComplaintType.setText(model.getSubcomplainttype());
        holder.systemId.setText(model.getSystemId());
        holder.rollNo.setText(model.getRollNo());
        holder.course.setText(model.getCourse());
        holder.description.setText(model.getDescription());
        holder.ActionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                Dialog dialog = new Dialog(activity);
                dialog.setContentView(R.layout.statuschangedialog);

                TextView complaintID = dialog.findViewById(R.id.takeActionTxt2);
                Button closeBtn = dialog.findViewById(R.id.close_btn);
                Button submitBtn = dialog.findViewById(R.id.submit_btn);

                closeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                String[] items = {"Reviewed","In Progress", "Completed"};
                AutoCompleteTextView autoCompleteTextView;
                ArrayAdapter<String> adapterItems;
                autoCompleteTextView = dialog.findViewById(R.id.auto_complete_text2);
                adapterItems = new ArrayAdapter<>(activity, R.layout.traffic_issue_list_item, items);
                autoCompleteTextView.setAdapter(adapterItems);
                autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        statusType = items[ (int) adapterView.getItemIdAtPosition(i) ];
                    }
                });

                String s = "Complaint Id : " + model.getComplaintid();
                complaintID.setText(s);

                submitBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(statusType != null){
                            DatabaseReference UserComplaint = FirebaseDatabase.getInstance().getReference("Sharda University").child("UserComplaints").child(model.getUserid()).child(model.getComplaintid());
                            UserComplaint.child("status").setValue(statusType);

                            UserComplaint.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    complaintType2 = Objects.requireNonNull(snapshot.child("complainttype").getValue()).toString();
                                    DatabaseReference AdminComplaint = FirebaseDatabase
                                            .getInstance()
                                            .getReference("Sharda University")
                                            .child("AdminComplaints")
                                            .child(complaintType2)
                                            .child(model.getComplaintid());
                                    AdminComplaint.child("status").setValue(statusType);
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {}
                            });
                            dialog.dismiss();
                        } else Toast.makeText(activity, "Please Select status", Toast.LENGTH_SHORT).show();
                    }
                });

                dialog.setCanceledOnTouchOutside(false);
                dialog.getWindow().setBackgroundDrawableResource(R.drawable.dialog);
                dialog.show();
            }
        });
    }

    @NonNull
    @Override
    public myviewholder4 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.adminshardacomplaint, parent, false);
        return new AdminShardaComplaintAdapter.myviewholder4(view);
    }

    public class myviewholder4 extends RecyclerView.ViewHolder{

        TextView complaintId, date, time, status, userId, systemId, course, rollNo, description, subComplaintType;
        Button ActionBtn;


        public myviewholder4(@NonNull View itemView) {
            super(itemView);

            complaintId = itemView.findViewById(R.id.complaintId);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            status = itemView.findViewById(R.id.status);
            userId = itemView.findViewById(R.id.userId);
            systemId = itemView.findViewById(R.id.systemId);
            course = itemView.findViewById(R.id.course);
            rollNo = itemView.findViewById(R.id.rollNo);
            description = itemView.findViewById(R.id.description);
            subComplaintType = itemView.findViewById(R.id.subComplaintType);
            ActionBtn = itemView.findViewById(R.id.AdminComplaintActionBtn);
        }
    }

}
