package in.ac.sharda.complaintbox;

import android.app.Dialog;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class AdminComplaintAdapter extends FirebaseRecyclerAdapter<AdminComplaintModel, AdminComplaintAdapter.myviewholder3> {

    public String statusType, complaintType2, department2;

    public AdminComplaintAdapter(@NonNull FirebaseRecyclerOptions<AdminComplaintModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder3 holder, int position, @NonNull AdminComplaintModel model) {

        holder.complaintId.setText(model.getComplaintid());
        holder.date.setText(model.getDate());
        holder.time.setText(model.getTime());
        holder.status.setText(model.getStatus());
        holder.userId.setText(model.getUserid());
        holder.subComplaintType.setText(model.getSubcomplainttype());
        holder.state.setText(model.getState());
        holder.city.setText(model.getCity());
        holder.locality.setText(model.getLocality());
        holder.description.setText(model.getDescription());
        holder.ActionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                Dialog dialog = new Dialog(activity);
                dialog.setContentView(R.layout.statuschangedialog);

                TextView complaintID = dialog.findViewById(R.id.takeActionTxt2);
                Button closeBtn = dialog.findViewById(R.id.close_btn);
                Button submitBtn = dialog.findViewById(R.id.submit_btn);

                closeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });

                String[] items = {"Reviewed","In Progress", "Completed"};
                AutoCompleteTextView autoCompleteTextView;
                ArrayAdapter<String> adapterItems;
                autoCompleteTextView = dialog.findViewById(R.id.auto_complete_text2);
                adapterItems = new ArrayAdapter<>(activity, R.layout.traffic_issue_list_item, items);
                autoCompleteTextView.setAdapter(adapterItems);
                autoCompleteTextView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                        statusType = items[ (int) adapterView.getItemIdAtPosition(i) ];
                    }
                });

                String s = "Complaint Id : " + model.getComplaintid();
                complaintID.setText(s);

                submitBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if(statusType != null){
                            DatabaseReference UserComplaint = FirebaseDatabase.getInstance().getReference("UserComplaints").child(model.getUserid()).child(model.getComplaintid());
                            UserComplaint.child("status").setValue(statusType);

                            UserComplaint.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    complaintType2 = Objects.requireNonNull(snapshot.child("complainttype").getValue()).toString();
                                    department2 =  Objects.requireNonNull(snapshot.child("department").getValue()).toString();
                                    System.out.println(department2);
                                    System.out.println(complaintType2);
                                    DatabaseReference AdminComplaint = FirebaseDatabase
                                            .getInstance()
                                            .getReference("Complaints")
                                            .child(department2)
                                            .child(complaintType2)
                                            .child(model.getComplaintid());
                                    AdminComplaint.child("status").setValue(statusType);
                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {}
                            });
                            dialog.dismiss();
                        } else Toast.makeText(activity, "Please Select status", Toast.LENGTH_SHORT).show();
                    }
                });

                dialog.setCanceledOnTouchOutside(false);
                dialog.getWindow().setBackgroundDrawableResource(R.drawable.dialog);
                dialog.show();
            }
        });

    }

    @NonNull
    @Override
    public myviewholder3 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.admincomplaint, parent, false);
        return new AdminComplaintAdapter.myviewholder3(view);
    }

    public class myviewholder3 extends RecyclerView.ViewHolder{

        TextView complaintId, date, time, status, userId, state, locality, city, description, subComplaintType;
        Button ActionBtn;


        public myviewholder3(@NonNull View itemView) {
            super(itemView);

            complaintId = itemView.findViewById(R.id.complaintId);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            status = itemView.findViewById(R.id.status);
            userId = itemView.findViewById(R.id.userId);
            state = itemView.findViewById(R.id.state);
            locality = itemView.findViewById(R.id.locality);
            city = itemView.findViewById(R.id.city);
            description = itemView.findViewById(R.id.description);
            subComplaintType = itemView.findViewById(R.id.subComplaintType);
            ActionBtn = itemView.findViewById(R.id.AdminComplaintActionBtn);

            if (status.getText().equals("Cancelled")) status.setTextColor(Color.RED);

        }
    }




}
