package in.ac.sharda.complaintbox;

import android.app.AlertDialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import io.paperdb.Paper;

public class SubsidiaryFragment extends Fragment {

    FirebaseDatabase rootNode;
    DatabaseReference referenceOfComplaintToAdmin, referenceOfComplaintToUser;

    ImageView back_IC;
    String[] items = {"Transport Services", "Food Services", "Lodging", "Medical and Health Services", "Others"};
    AutoCompleteTextView autoCompleteTextView;
    ArrayAdapter<String> adapterItems;
    private String complaintType;
    EditText state_ET, city_ET, locality_ET, description_ET;
    Button raiseComplaintBtn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.fragment_subsidiary, container, false);

        back_IC = v.findViewById(R.id.back_ic);
        autoCompleteTextView = v.findViewById(R.id.auto_complete_text);
        state_ET = v.findViewById(R.id.state_et);
        city_ET = v.findViewById(R.id.city_et);
        locality_ET = v.findViewById(R.id.locality_et);
        description_ET = v.findViewById(R.id.description_et);
        raiseComplaintBtn = v.findViewById(R.id.submitComplaint_btn);
        Paper.init(requireActivity());

        back_IC.setOnClickListener(view -> {
            Fragment fragment = new EducationFragment();
            FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.fragmentContainerView, fragment).commit();
        });

        adapterItems = new ArrayAdapter<>(getActivity(), R.layout.traffic_issue_list_item, items);
        autoCompleteTextView.setAdapter(adapterItems);
        autoCompleteTextView.setOnItemClickListener((adapterView, view, i, l) ->
                        complaintType = items[ (int) adapterView.getItemIdAtPosition(i)]
                /*String.valueOf(adapterView.getItemIdAtPosition(i))*/);

        raiseComplaintBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (state_ET.getText().toString().isEmpty() ||
                        city_ET.getText().toString().isEmpty() ||
                        locality_ET.getText().toString().isEmpty() ||
                        description_ET.getText().toString().isEmpty() ||
                        complaintType == null){
                    Toast.makeText(getActivity(), "Enter details", Toast.LENGTH_SHORT).show();
                } else{
                    submitComplaintInfo();
                }
            }
        });
        return v;
    }

    private void submitComplaintInfo() {
        final String saveCurrentTime, saveCurrentDate, complaintId2, complaintId1;
        Calendar calForDate = Calendar.getInstance();
        SimpleDateFormat currentDate = new SimpleDateFormat("MM,dd,yyyy");
        saveCurrentDate = currentDate.format(calForDate.getTime());
        SimpleDateFormat currentTime = new SimpleDateFormat("HH,mm,ss a");
        saveCurrentTime = currentTime.format(calForDate.getTime());

        SimpleDateFormat currentDate1 = new SimpleDateFormat("MMddyyyy");
        complaintId1 = currentDate1.format(calForDate.getTime());
        SimpleDateFormat currentTime2 = new SimpleDateFormat("HHmmss");
        complaintId2 = currentTime2.format(calForDate.getTime());

        String complaintID = complaintId1 + complaintId2;
        String state = state_ET.getText().toString();
        String city = city_ET.getText().toString();
        String locality = locality_ET.getText().toString();
        String description = description_ET.getText().toString();

        String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);
        rootNode = FirebaseDatabase.getInstance();
        referenceOfComplaintToAdmin = rootNode.getReference("Complaints").child("Education Department").child("Education Subsidiary").child(complaintID);
        referenceOfComplaintToUser = rootNode.getReference("UserComplaints").child(UserPhoneKey).child(complaintID);
        final HashMap<String, Object> complaintMap = new HashMap<>();
        complaintMap.put("complaintid",complaintID);
        complaintMap.put("date", saveCurrentDate);
        complaintMap.put("userid", UserPhoneKey);
        complaintMap.put("time", saveCurrentTime);
        complaintMap.put("status", "Submitted");
        complaintMap.put("state", state);
        complaintMap.put("city", city);
        complaintMap.put("locality", locality);
        complaintMap.put("description", description);
        complaintMap.put("subcomplainttype", complaintType);

        referenceOfComplaintToAdmin.updateChildren(complaintMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful()){
                    complaintMap.put("department","Education Department");
                    complaintMap.put("complainttype", "Education Subsidiary");
                    referenceOfComplaintToUser.updateChildren(complaintMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (!task.isSuccessful())
                                Toast.makeText(getActivity(), "Error occurred in updating userView of complaints", Toast.LENGTH_SHORT).show();
                        }
                    });

                    AlertDialog.Builder builder1 = new AlertDialog.Builder(getActivity());
                    builder1.setTitle("Complaint Submitted");
                    builder1.setMessage("Your complaint is submitted, Department will review and notify you");
                    builder1.setCancelable(false);
                    builder1.setPositiveButton(
                            "Go to home",
                            (dialog, id) -> {
                                Fragment fragment = new HomeFragment();
                                FragmentTransaction fragmentTransaction = requireActivity().getSupportFragmentManager().beginTransaction();
                                fragmentTransaction.replace(R.id.fragmentContainerView, fragment).commit();
                                FragmentManager fm = requireActivity().getSupportFragmentManager();
                                for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                    fm.popBackStack();
                                }
                            });


                    AlertDialog alert11 = builder1.create();
                    alert11.show();
                }else  {
                    Toast.makeText(getActivity(), "Error occurred", Toast.LENGTH_SHORT).show();
                }


            }
        });


    }
}