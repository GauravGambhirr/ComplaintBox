package in.ac.sharda.complaintbox;

import android.app.AlertDialog;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import io.paperdb.Paper;

public class MyShardaComplaintAdapter extends FirebaseRecyclerAdapter<ShardaComplaintModel, MyShardaComplaintAdapter.myviewholder1> {

    public MyShardaComplaintAdapter(@NonNull FirebaseRecyclerOptions<ShardaComplaintModel> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myviewholder1 holder, int position, @NonNull ShardaComplaintModel model) {

        holder.complaintType.setText(model.getComplainttype());
        holder.complaintId.setText(model.getComplaintid());
        holder.date.setText(model.getDate());
        holder.time.setText(model.getTime());
        holder.status.setText(model.getStatus());
        holder.systemId.setText(model.getSystemId());
        holder.rollNo.setText(model.getRollNo());
        holder.description.setText(model.getDescription());
        holder.subComplaintType.setText(model.getSubcomplainttype());


        holder.cancelBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AppCompatActivity activity = (AppCompatActivity)view.getContext();
                Paper.init(activity);
                if (!(model.status).equals("Cancelled")){
                    AlertDialog.Builder builder2 = new AlertDialog.Builder(activity);
                    builder2.setTitle("Cancel Complaint");
                    builder2.setMessage("Are you sure, you want to Cancel the Complaint");
                    builder2.setCancelable(true);
                    builder2.setPositiveButton(
                        "Yes",
                        (dialog, id) -> {
                            deleteComplaint(model.getComplaintid());
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(activity);
                            builder1.setTitle("Complaint Cancelled");
                            builder1.setMessage("Your complaint is cancelled.");
                            builder1.setCancelable(false);
                            builder1.setPositiveButton(
                                    "Go to home",
                                    (dialog1, id1) -> {
                                        Fragment fragment = new ShardaFragment();
                                        FragmentTransaction fragmentTransaction = activity.getSupportFragmentManager().beginTransaction();
                                        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).commit();
                                        FragmentManager fm = activity.getSupportFragmentManager();
                                        for(int i = 0; i < fm.getBackStackEntryCount(); ++i) {
                                            fm.popBackStack();
                                        }
                                    });
                            AlertDialog alert11 = builder1.create();
                            alert11.show();
                        });
                    builder2.setNegativeButton(
                            "No",
                            (dialog, id) -> dialog.cancel());
                    AlertDialog alert12 = builder2.create();
                    alert12.show();
                }else {
                    Toast.makeText(activity,"This complaint is already cancelled.",Toast.LENGTH_SHORT).show();
                }
            }

            private void deleteComplaint(String ComplaintId) {
                String UserPhoneKey = Paper.book().read(Prevalent.UserPhoneKey);
                DatabaseReference UserComplaint = FirebaseDatabase.getInstance().getReference("Sharda University").child("UserComplaints").child(UserPhoneKey).child(ComplaintId);
                UserComplaint.child("status").setValue("Cancelled");

                DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Sharda University").child("AdminComplaints").child(model.complainttype).child(ComplaintId);
                AdminComplaint.child("status").setValue("Cancelled");





//                switch (String.valueOf(holder.complaintType)) {
//                    case "Accounts": {
//                        DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Sharda University").child("AdminComplaints").child("Accounts").child(ComplaintId);
//                        AdminComplaint.child("status").setValue("Cancelled");
//                        holder.status.setTextColor(Color.RED);
//                        break;
//                    }
//                    case "Disputes": {
//                        DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Sharda University").child("AdminComplaints").child("Disputes").child(ComplaintId);
//                        AdminComplaint.child("status").setValue("Cancelled");
//                        holder.status.setTextColor(Color.RED);
//                        break;
//                    }
//                    case "Mismanagement": {
//                        DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Sharda University").child("AdminComplaints").child("Mismanagement").child(ComplaintId);
//                        AdminComplaint.child("status").setValue("Cancelled");
//                        holder.status.setTextColor(Color.RED);
//                        break;
//                    }
//                    case "Misconduct": {
//                        DatabaseReference AdminComplaint = FirebaseDatabase.getInstance().getReference("Sharda University").child("AdminComplaints").child("Misconduct").child(ComplaintId);
//                        AdminComplaint.child("status").setValue("Cancelled");
//                        holder.status.setTextColor(Color.RED);
//                        break;
//                    }
//                }
            }
        });
//        holder.myShardaComplaintCV.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                AppCompatActivity activity = (AppCompatActivity)view.getContext();
//                activity.getSupportFragmentManager().beginTransaction().replace(R.id.fragmentContainerView, new MyComplaintDetails(
//                        model.getCity(),
//                        model.getComplaintid(),
//                        model.getComplainttype(),
//                        model.getDate(),
//                        model.getDepartment(),
//                        model.getDescription(),
//                        model.getLocality(),
//                        model.getState(),
//                        model.getStatus(),
//                        model.getSubcomplainttype(),
//                        model.getTime(),
//                        model.getUserid()
//                )).addToBackStack(null).commit();
//            }
//        });


    }

    @NonNull
    @Override
    public myviewholder1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.myshardacomplaint, parent, false);
        return new myviewholder1(view);
    }

    public class myviewholder1 extends RecyclerView.ViewHolder{

        TextView complaintType, complaintId, date, time, status, subComplaintType, systemId, rollNo, description;
        CardView myShardaComplaintCV;
        Button cancelBtn;

        public myviewholder1(@NonNull View itemView) {
            super(itemView);

            subComplaintType = itemView.findViewById(R.id.subComplaintType);
            complaintType = itemView.findViewById(R.id.complaintType);
            complaintId = itemView.findViewById(R.id.complaintId);
            date = itemView.findViewById(R.id.date);
            time = itemView.findViewById(R.id.time);
            description = itemView.findViewById(R.id.description);
            rollNo = itemView.findViewById(R.id.rollNo);
            systemId = itemView.findViewById(R.id.systemId);
            status = itemView.findViewById(R.id.status);
            myShardaComplaintCV = itemView.findViewById(R.id.myShardaComplaintCV);
            cancelBtn = itemView.findViewById(R.id.shardaCancelComplaintBtn);

            if (status.getText().equals("Cancelled")) status.setTextColor(Color.RED);

        }
    }


}
