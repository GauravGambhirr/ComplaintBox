package in.ac.sharda.complaintbox;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentContainerView;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

public class HomeFragment extends Fragment {

    RelativeLayout transport_rl, security_rl, health_rl, education_rl;
    CardView transport_cv, security_cv, health_cv, education_cv,sharda_cv, mcd_cv, electricity_cv;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_home,container,false);

        transport_rl = v.findViewById(R.id.transport_RL);
        transport_cv = v.findViewById(R.id.transport_CV);
        security_rl = v.findViewById(R.id.security_RL);
        security_cv = v.findViewById(R.id.security_CV);
        health_rl = v.findViewById(R.id.health_RL);
        health_cv = v.findViewById(R.id.health_CV);
        education_rl = v.findViewById(R.id.education_RL);
        education_cv = v.findViewById(R.id.education_CV);
        sharda_cv = v.findViewById(R.id.sharda_university_CV);
        mcd_cv = v.findViewById(R.id.mcd_CV);
        electricity_cv = v.findViewById(R.id.electricity_CV);

        transport_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenTransportFragment();
            }
        });
        transport_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenTransportFragment();
            }
        });
        security_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenSecurityFragment();
            }
        });
        security_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenSecurityFragment();
            }
        });
        health_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenHealthFragment();
            }
        });
        health_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenHealthFragment();
            }
        });
        education_rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenEducationFragment();
            }
        });
        education_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenEducationFragment();
            }
        });
        sharda_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenShardaFragment();     
            }
        });
        mcd_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenMCDFragment();
            }
        });
        electricity_cv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                OpenElectricityFragment();
            }
        });

        return v;
    }

    private void OpenElectricityFragment() {
        Fragment fragment = new ElectricityFragment();
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack( "tag" ).commit();
    }

    private void OpenMCDFragment() {
        Fragment fragment = new MCDFragment();
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack( "tag" ).commit();
    }

    private void OpenShardaFragment() {
        Fragment fragment = new ShardaFragment();
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack( "tag" ).commit();
    }
    private void OpenEducationFragment() {
        Fragment fragment = new EducationFragment();
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack( "tag" ).commit();
    }
    private void OpenHealthFragment() {
        Fragment fragment = new HealthFragment();
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack( "tag" ).commit();
    }
    private void OpenSecurityFragment() {
        Fragment fragment = new SecurityFragment();
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack( "tag" ).commit();
    }
    private void OpenTransportFragment() {
        Fragment fragment = new TransportFragment();
        FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragmentContainerView, fragment).addToBackStack( "tag" ).commit();
    }
}
